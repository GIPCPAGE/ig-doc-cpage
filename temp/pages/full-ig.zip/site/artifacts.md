# Artifacts Summary - Template d'IG FHIR en Français v1.0.0

* [**Table of Contents**](toc.md)
* **Artifacts Summary**

## Artifacts Summary

This page provides a list of the FHIR artifacts defined as part of this implementation guide.

### Structures: Resource Profiles 

These define constraints on FHIR resources for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Mon Profil Patient](StructureDefinition-mon-profil.md) | Un exemple de profil patient personnalisé |

